// ═══════════════════════════════════════════════════════════
// CHATORIO — Content Script
// Runs on ChatGPT, Claude, Gemini, DeepSeek
// Detects platform, reads conversations, sends to background
// ═══════════════════════════════════════════════════════════

import { detectPlatform } from "@/lib/platforms";

export default defineContentScript({
  matches: [
    "https://chat.openai.com/*",
    "https://chatgpt.com/*",
    "https://claude.ai/*",
    "https://gemini.google.com/*",
    "https://chat.deepseek.com/*",
  ],
  runAt: "document_idle",

  main() {
    console.log("[Chatorio] Content script loaded on:", window.location.href);

    const adapter = detectPlatform();
    if (!adapter) {
      console.log("[Chatorio] No matching platform adapter found");
      return;
    }

    console.log(`[Chatorio] Platform detected: ${adapter.platform}`);

    // Notify background about which platform we're on
    chrome.runtime.sendMessage({
      type: "PLATFORM_DETECTED",
      platform: adapter.platform,
    });

    // Start observing conversation list changes
    adapter.observeChanges((conversations) => {
      console.log(
        `[Chatorio] ${conversations.length} conversations found on ${adapter.platform}`
      );

      // Send to background (which forwards to side panel)
      chrome.runtime.sendMessage({
        type: "CONVERSATIONS_UPDATE",
        conversations,
      });
    });

    // Listen for requests from the side panel
    chrome.runtime.onMessage.addListener((message) => {
      if (
        message.type === "GET_CONVERSATIONS" &&
        message.platform === adapter.platform
      ) {
        const conversations = adapter.getConversations();
        chrome.runtime.sendMessage({
          type: "CONVERSATIONS_UPDATE",
          conversations,
        });
      }
    });
  },
});
