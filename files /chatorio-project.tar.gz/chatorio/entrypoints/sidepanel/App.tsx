// ═══════════════════════════════════════════════════════════
// CHATORIO — Side Panel App
// Main entry point for the side panel React application
// ═══════════════════════════════════════════════════════════

import { useEffect } from "react";
import { useStore } from "@/lib/store";
import { Header } from "@/components/Header";
import { SearchBar } from "@/components/SearchBar";
import { PlatformFilter } from "@/components/PlatformFilter";
import { TabBar } from "@/components/TabBar";
import { FolderList } from "@/components/FolderList";
import { StatusBar } from "@/components/StatusBar";

export default function App() {
  const { loadAll, updateConversations, isLoading } = useStore();

  useEffect(() => {
    // Load persisted state on mount
    loadAll();

    // Listen for conversation updates from content scripts
    const listener = (message: any) => {
      if (message.type === "CONVERSATIONS_UPDATE" && message.conversations) {
        updateConversations(message.conversations);
      }
    };

    chrome.runtime.onMessage.addListener(listener);
    return () => chrome.runtime.onMessage.removeListener(listener);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-500 to-brand-600 animate-pulse" />
          <span className="text-xs text-gray-500">Cargando...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-surface">
      <Header />
      <div className="px-3 pt-2 pb-1.5 border-b border-white/5 space-y-2">
        <SearchBar />
        <PlatformFilter />
      </div>
      <TabBar />
      <div className="flex-1 overflow-y-auto px-2 py-2">
        <FolderList />
      </div>
      <StatusBar />
    </div>
  );
}
