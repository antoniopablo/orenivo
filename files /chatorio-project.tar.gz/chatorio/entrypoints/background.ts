// ═══════════════════════════════════════════════════════════
// CHATORIO — Background Service Worker
// Handles: side panel toggling, message routing between
// content scripts and side panel, platform detection
// ═══════════════════════════════════════════════════════════

export default defineBackground(() => {
  console.log("[Chatorio] Background service worker started");

  // Open side panel when extension icon is clicked
  chrome.action.onClicked.addListener(async (tab) => {
    if (tab.id) {
      try {
        await chrome.sidePanel.open({ tabId: tab.id });
      } catch (err) {
        console.error("[Chatorio] Failed to open side panel:", err);
      }
    }
  });

  // Enable side panel on supported sites
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

  // Route messages between content scripts and side panel
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "CONVERSATIONS_UPDATE") {
      // Forward to all extension pages (side panel will pick this up)
      chrome.runtime
        .sendMessage(message)
        .catch(() => {
          // Side panel might not be open, that's OK
        });
    }

    if (message.type === "PLATFORM_DETECTED") {
      console.log(
        `[Chatorio] Platform detected: ${message.platform} on tab ${sender.tab?.id}`
      );
    }

    if (message.type === "OPEN_SIDEPANEL" && sender.tab?.id) {
      chrome.sidePanel.open({ tabId: sender.tab.id });
    }

    return false; // No async response needed
  });
});
