# 🗂️ Chatorio

**Organize your AI chats: Folders, Search & Prompts for ChatGPT, Claude, Gemini & DeepSeek**

The only Chrome extension that organizes all your AI conversations in one place.

## ✨ Features

- 📁 **Folders & Subfolders** — Color-coded, drag & drop
- 🔍 **Instant Search** — Find any conversation across all platforms
- ⚡ **Prompt Manager** — Save & reuse templates with variables
- 🌐 **4 Platforms** — ChatGPT, Claude, Gemini, DeepSeek
- 📌 **Pins** — Quick access to your most important chats
- ☁️ **Cloud Sync** (Pro) — Across all your browsers

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development (loads extension in Chrome)
npm run dev

# Build for production
npm run build

# Create .zip for Chrome Web Store submission
npm run zip
```

### Load in Chrome (development)

1. Run `npm run dev`
2. Open `chrome://extensions`
3. Enable "Developer mode"
4. Click "Load unpacked"
5. Select the `.output/chrome-mv3` directory
6. Open ChatGPT or Claude — click the Chatorio icon to open the side panel

## 🏗️ Architecture

```
chatorio/
├── entrypoints/
│   ├── background.ts          # Service worker — message routing, side panel
│   ├── content.ts             # Content script — runs on AI platforms
│   └── sidepanel/             # React app — the main UI
│       ├── index.html
│       ├── main.tsx
│       └── App.tsx
├── components/                # React components
│   ├── Header.tsx
│   ├── SearchBar.tsx
│   ├── PlatformFilter.tsx
│   ├── TabBar.tsx
│   ├── FolderList.tsx
│   ├── ConversationItem.tsx
│   ├── PlatformBadge.tsx
│   └── StatusBar.tsx
├── lib/
│   ├── types.ts               # TypeScript types & constants
│   ├── storage.ts             # chrome.storage.local abstraction
│   ├── store/index.ts         # Zustand state management
│   └── platforms/             # Platform adapters (one per AI service)
│       ├── adapter.ts         # Interface + helpers
│       ├── chatgpt.ts         # ChatGPT DOM adapter
│       ├── claude.ts          # Claude DOM adapter
│       └── index.ts           # Platform registry
├── assets/
│   └── styles.css             # Tailwind + custom styles
└── public/
    └── icons/                 # Extension icons (16,32,48,128 PNG)
```

### How it works

1. **Content script** loads on ChatGPT/Claude/Gemini/DeepSeek
2. **Platform adapter** reads conversation list from the DOM using `MutationObserver`
3. Conversations are sent via `chrome.runtime.sendMessage` to the **background service worker**
4. Background forwards to the **side panel** React app
5. **Zustand store** manages UI state, **chrome.storage.local** persists data
6. When the user creates folders/pins, changes are saved to storage
7. Conversation metadata (titles, folders, pins) persists across sessions

### Adding a new platform

1. Create `lib/platforms/newplatform.ts` implementing `PlatformAdapter`
2. Add selectors for the platform's conversation list DOM
3. Register in `lib/platforms/index.ts`
4. Add host permission in `wxt.config.ts`

## 📝 Tech Stack

- **WXT** — Chrome extension framework (Manifest V3)
- **React 18** — UI framework
- **TypeScript** — Type safety
- **Tailwind CSS** — Styling
- **Zustand** — State management
- **chrome.storage.local** — Persistent storage (free tier)
- **Supabase** — Cloud sync (Pro tier, planned)
- **Lemon Squeezy** — Payments (planned)

## 📄 License

MIT — see LICENSE

## 🙋 Support

- Chrome Web Store: [link pending]
- GitHub Issues: [link pending]  
- Email: support@chatorio.com

---

Made with ☕ from Spain
