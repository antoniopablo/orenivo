// ═══════════════════════════════════════════════════════════
// CHATORIO — Zustand Store
// Central state management for the side panel UI
// ═══════════════════════════════════════════════════════════

import { create } from "zustand";
import type { Folder, Conversation, PromptTemplate, Platform } from "../types";
import { FOLDER_COLORS } from "../types";
import * as storage from "../storage";

interface ChatorioStore {
  // State
  folders: Folder[];
  conversations: Conversation[];
  prompts: PromptTemplate[];
  searchQuery: string;
  platformFilter: Platform | "all";
  activeTab: "folders" | "recent" | "pinned";
  isLoading: boolean;

  // Actions — Data loading
  loadAll: () => Promise<void>;

  // Actions — Folders
  createFolder: (name: string, parentId?: string | null) => Promise<void>;
  renameFolder: (id: string, name: string) => Promise<void>;
  changeFolderColor: (id: string, color: string) => Promise<void>;
  removeFolder: (id: string) => Promise<void>;

  // Actions — Conversations
  updateConversations: (convs: Conversation[]) => Promise<void>;
  moveToFolder: (convId: string, platform: string, folderId: string | null) => Promise<void>;
  togglePinConversation: (convId: string, platform: string) => Promise<void>;

  // Actions — Prompts
  createPrompt: (name: string, text: string, platform?: Platform | "all") => Promise<void>;
  removePrompt: (id: string) => Promise<void>;

  // Actions — UI
  setSearchQuery: (query: string) => void;
  setPlatformFilter: (platform: Platform | "all") => void;
  setActiveTab: (tab: "folders" | "recent" | "pinned") => void;
}

export const useStore = create<ChatorioStore>((set, get) => ({
  folders: [],
  conversations: [],
  prompts: [],
  searchQuery: "",
  platformFilter: "all",
  activeTab: "folders",
  isLoading: true,

  // ── Data loading ──

  loadAll: async () => {
    set({ isLoading: true });
    const [folders, conversations, prompts] = await Promise.all([
      storage.getFolders(),
      storage.getConversations(),
      storage.getPrompts(),
    ]);
    set({ folders, conversations, prompts, isLoading: false });
  },

  // ── Folders ──

  createFolder: async (name, parentId = null) => {
    const { folders } = get();
    const newFolder: Folder = {
      id: storage.generateId(),
      name,
      color: FOLDER_COLORS[folders.length % FOLDER_COLORS.length],
      parentId,
      order: folders.filter((f) => f.parentId === parentId).length,
      createdAt: Date.now(),
    };
    await storage.addFolder(newFolder);
    set({ folders: [...folders, newFolder] });
  },

  renameFolder: async (id, name) => {
    await storage.updateFolder(id, { name });
    set({
      folders: get().folders.map((f) =>
        f.id === id ? { ...f, name } : f
      ),
    });
  },

  changeFolderColor: async (id, color) => {
    await storage.updateFolder(id, { color });
    set({
      folders: get().folders.map((f) =>
        f.id === id ? { ...f, color } : f
      ),
    });
  },

  removeFolder: async (id) => {
    await storage.deleteFolder(id);
    // Reload from storage to get clean state (cascade deletes children)
    const [folders, conversations] = await Promise.all([
      storage.getFolders(),
      storage.getConversations(),
    ]);
    set({ folders, conversations });
  },

  // ── Conversations ──

  updateConversations: async (convs) => {
    await storage.upsertConversations(convs);
    const conversations = await storage.getConversations();
    set({ conversations });
  },

  moveToFolder: async (convId, platform, folderId) => {
    await storage.moveConversationToFolder(convId, platform, folderId);
    set({
      conversations: get().conversations.map((c) =>
        c.id === convId && c.platform === platform
          ? { ...c, folderId }
          : c
      ),
    });
  },

  togglePinConversation: async (convId, platform) => {
    await storage.togglePin(convId, platform);
    set({
      conversations: get().conversations.map((c) =>
        c.id === convId && c.platform === platform
          ? { ...c, pinned: !c.pinned }
          : c
      ),
    });
  },

  // ── Prompts ──

  createPrompt: async (name, text, platform = "all") => {
    const newPrompt: PromptTemplate = {
      id: storage.generateId(),
      name,
      text,
      folderId: null,
      platform,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    await storage.addPrompt(newPrompt);
    set({ prompts: [...get().prompts, newPrompt] });
  },

  removePrompt: async (id) => {
    await storage.deletePrompt(id);
    set({ prompts: get().prompts.filter((p) => p.id !== id) });
  },

  // ── UI ──

  setSearchQuery: (searchQuery) => set({ searchQuery }),
  setPlatformFilter: (platformFilter) => set({ platformFilter }),
  setActiveTab: (activeTab) => set({ activeTab }),
}));
