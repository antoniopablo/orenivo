// ═══════════════════════════════════════════════════════════
// CHATORIO — ChatGPT Adapter
// Reads conversation list from chat.openai.com / chatgpt.com
//
// NOTE: ChatGPT frequently changes their DOM structure.
// All selectors use fallback chains for resilience.
// When something breaks, update the selectors here only.
// ═══════════════════════════════════════════════════════════

import type { Conversation } from "../types";
import {
  PlatformAdapter,
  queryAllWithFallback,
} from "./adapter";

// Selector chains — ordered from most specific (current) to fallback
const SIDEBAR_SELECTORS = [
  "nav[aria-label='Chat history']",
  "nav.flex-col",
  "#__next nav",
];

const CONVERSATION_ITEM_SELECTORS = [
  "nav[aria-label='Chat history'] a[href^='/c/']",
  "nav a[href^='/c/']",
  "a[href^='/c/']",
];

export class ChatGPTAdapter implements PlatformAdapter {
  platform = "chatgpt" as const;
  private observer: MutationObserver | null = null;

  matches(url: string): boolean {
    return (
      url.includes("chat.openai.com") || url.includes("chatgpt.com")
    );
  }

  getConversations(): Conversation[] {
    const links = queryAllWithFallback(CONVERSATION_ITEM_SELECTORS);
    const conversations: Conversation[] = [];

    for (const link of links) {
      const href = link.getAttribute("href");
      if (!href || !href.startsWith("/c/")) continue;

      const id = href.replace("/c/", "").split("?")[0];
      const title =
        link.textContent?.trim() || "Untitled conversation";

      conversations.push({
        id,
        title,
        platform: "chatgpt",
        url: `${window.location.origin}${href}`,
        lastAccessed: Date.now(),
        pinned: false,
        folderId: null,
      });
    }

    return conversations;
  }

  observeChanges(callback: (conversations: Conversation[]) => void): void {
    this.disconnect();

    // Debounce to avoid excessive updates during rapid DOM changes
    let timeout: ReturnType<typeof setTimeout>;
    const debouncedCallback = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        callback(this.getConversations());
      }, 500);
    };

    // Observe the sidebar for changes
    const observe = () => {
      const sidebar =
        document.querySelector(SIDEBAR_SELECTORS[0]) ||
        document.querySelector(SIDEBAR_SELECTORS[1]) ||
        document.querySelector(SIDEBAR_SELECTORS[2]);

      if (sidebar) {
        this.observer = new MutationObserver(debouncedCallback);
        this.observer.observe(sidebar, {
          childList: true,
          subtree: true,
          characterData: true,
        });
        // Initial read
        callback(this.getConversations());
      } else {
        // Sidebar not loaded yet, retry
        setTimeout(observe, 1000);
      }
    };

    observe();
  }

  disconnect(): void {
    this.observer?.disconnect();
    this.observer = null;
  }
}
