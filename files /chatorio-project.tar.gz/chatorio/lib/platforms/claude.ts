// ═══════════════════════════════════════════════════════════
// CHATORIO — Claude Adapter
// Reads conversation list from claude.ai
// ═══════════════════════════════════════════════════════════

import type { Conversation } from "../types";
import { PlatformAdapter, queryAllWithFallback } from "./adapter";

const CONVERSATION_SELECTORS = [
  "a[href^='/chat/']",
  "nav a[href*='/chat/']",
  "[data-testid='chat-link']",
];

export class ClaudeAdapter implements PlatformAdapter {
  platform = "claude" as const;
  private observer: MutationObserver | null = null;

  matches(url: string): boolean {
    return url.includes("claude.ai");
  }

  getConversations(): Conversation[] {
    const links = queryAllWithFallback(CONVERSATION_SELECTORS);
    const conversations: Conversation[] = [];
    const seen = new Set<string>();

    for (const link of links) {
      const href = link.getAttribute("href");
      if (!href || !href.includes("/chat/")) continue;

      // Extract conversation ID from URL
      const match = href.match(/\/chat\/([a-f0-9-]+)/);
      if (!match) continue;

      const id = match[1];
      if (seen.has(id)) continue;
      seen.add(id);

      const title = link.textContent?.trim() || "Untitled conversation";

      conversations.push({
        id,
        title,
        platform: "claude",
        url: `https://claude.ai${href}`,
        lastAccessed: Date.now(),
        pinned: false,
        folderId: null,
      });
    }

    return conversations;
  }

  observeChanges(callback: (conversations: Conversation[]) => void): void {
    this.disconnect();

    let timeout: ReturnType<typeof setTimeout>;
    const debouncedCallback = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        callback(this.getConversations());
      }, 500);
    };

    const observe = () => {
      // Claude uses a sidebar that we need to observe
      const sidebar =
        document.querySelector("nav") ||
        document.querySelector("[class*='sidebar']") ||
        document.body;

      this.observer = new MutationObserver(debouncedCallback);
      this.observer.observe(sidebar, {
        childList: true,
        subtree: true,
        characterData: true,
      });

      callback(this.getConversations());
    };

    // Wait for page to be ready
    if (document.readyState === "complete") {
      setTimeout(observe, 1000);
    } else {
      window.addEventListener("load", () => setTimeout(observe, 1000));
    }
  }

  disconnect(): void {
    this.observer?.disconnect();
    this.observer = null;
  }
}
