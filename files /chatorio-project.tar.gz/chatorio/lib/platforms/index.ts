// ═══════════════════════════════════════════════════════════
// CHATORIO — Platform Registry
// Detects which AI platform we're on and returns the adapter
// ═══════════════════════════════════════════════════════════

import type { PlatformAdapter } from "./adapter";
import { ChatGPTAdapter } from "./chatgpt";
import { ClaudeAdapter } from "./claude";

// Register all adapters here. When you add Gemini/DeepSeek,
// just import and add to this array.
const adapters: PlatformAdapter[] = [
  new ChatGPTAdapter(),
  new ClaudeAdapter(),
  // TODO Sprint 6: new GeminiAdapter(),
  // TODO Sprint 6: new DeepSeekAdapter(),
];

/**
 * Detect which platform adapter matches the current URL.
 * Returns null if we're not on a supported platform.
 */
export function detectPlatform(
  url: string = window.location.href
): PlatformAdapter | null {
  for (const adapter of adapters) {
    if (adapter.matches(url)) {
      return adapter;
    }
  }
  return null;
}

export { adapters };
