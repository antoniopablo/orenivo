// ═══════════════════════════════════════════════════════════
// CHATORIO — Storage Layer
// Abstraction over chrome.storage.local for all persistent data
// ═══════════════════════════════════════════════════════════

import type { Folder, Conversation, PromptTemplate, AppState } from "./types";

const STORAGE_KEYS = {
  folders: "chatorio_folders",
  conversations: "chatorio_conversations",
  prompts: "chatorio_prompts",
  settings: "chatorio_settings",
} as const;

// ── Generic helpers ──

async function get<T>(key: string, fallback: T): Promise<T> {
  try {
    const result = await chrome.storage.local.get(key);
    return result[key] ?? fallback;
  } catch {
    console.warn(`[Chatorio] Storage read failed for key: ${key}`);
    return fallback;
  }
}

async function set(key: string, value: unknown): Promise<void> {
  try {
    await chrome.storage.local.set({ [key]: value });
  } catch (err) {
    console.error(`[Chatorio] Storage write failed for key: ${key}`, err);
  }
}

// ── Folders ──

export async function getFolders(): Promise<Folder[]> {
  return get<Folder[]>(STORAGE_KEYS.folders, []);
}

export async function saveFolders(folders: Folder[]): Promise<void> {
  return set(STORAGE_KEYS.folders, folders);
}

export async function addFolder(folder: Folder): Promise<void> {
  const folders = await getFolders();
  folders.push(folder);
  await saveFolders(folders);
}

export async function updateFolder(
  id: string,
  updates: Partial<Folder>
): Promise<void> {
  const folders = await getFolders();
  const idx = folders.findIndex((f) => f.id === id);
  if (idx !== -1) {
    folders[idx] = { ...folders[idx], ...updates };
    await saveFolders(folders);
  }
}

export async function deleteFolder(id: string): Promise<void> {
  let folders = await getFolders();
  // Also delete child folders
  const idsToDelete = new Set<string>();
  const collectChildren = (parentId: string) => {
    idsToDelete.add(parentId);
    folders
      .filter((f) => f.parentId === parentId)
      .forEach((f) => collectChildren(f.id));
  };
  collectChildren(id);

  folders = folders.filter((f) => !idsToDelete.has(f.id));
  await saveFolders(folders);

  // Unfiled conversations from deleted folders
  const conversations = await getConversations();
  const updated = conversations.map((c) =>
    idsToDelete.has(c.folderId ?? "") ? { ...c, folderId: null } : c
  );
  await saveConversations(updated);
}

// ── Conversations ──

export async function getConversations(): Promise<Conversation[]> {
  return get<Conversation[]>(STORAGE_KEYS.conversations, []);
}

export async function saveConversations(
  conversations: Conversation[]
): Promise<void> {
  return set(STORAGE_KEYS.conversations, conversations);
}

export async function upsertConversation(conv: Conversation): Promise<void> {
  const conversations = await getConversations();
  const idx = conversations.findIndex(
    (c) => c.id === conv.id && c.platform === conv.platform
  );
  if (idx !== -1) {
    // Preserve folder assignment and pin status
    conversations[idx] = {
      ...conv,
      folderId: conversations[idx].folderId,
      pinned: conversations[idx].pinned,
    };
  } else {
    conversations.push(conv);
  }
  await saveConversations(conversations);
}

export async function upsertConversations(
  newConvs: Conversation[]
): Promise<void> {
  const existing = await getConversations();
  const map = new Map(
    existing.map((c) => [`${c.platform}:${c.id}`, c])
  );

  for (const conv of newConvs) {
    const key = `${conv.platform}:${conv.id}`;
    const old = map.get(key);
    if (old) {
      map.set(key, {
        ...conv,
        folderId: old.folderId,
        pinned: old.pinned,
      });
    } else {
      map.set(key, conv);
    }
  }

  await saveConversations(Array.from(map.values()));
}

export async function moveConversationToFolder(
  conversationId: string,
  platform: string,
  folderId: string | null
): Promise<void> {
  const conversations = await getConversations();
  const idx = conversations.findIndex(
    (c) => c.id === conversationId && c.platform === platform
  );
  if (idx !== -1) {
    conversations[idx].folderId = folderId;
    await saveConversations(conversations);
  }
}

export async function togglePin(
  conversationId: string,
  platform: string
): Promise<void> {
  const conversations = await getConversations();
  const idx = conversations.findIndex(
    (c) => c.id === conversationId && c.platform === platform
  );
  if (idx !== -1) {
    conversations[idx].pinned = !conversations[idx].pinned;
    await saveConversations(conversations);
  }
}

// ── Prompts ──

export async function getPrompts(): Promise<PromptTemplate[]> {
  return get<PromptTemplate[]>(STORAGE_KEYS.prompts, []);
}

export async function savePrompts(prompts: PromptTemplate[]): Promise<void> {
  return set(STORAGE_KEYS.prompts, prompts);
}

export async function addPrompt(prompt: PromptTemplate): Promise<void> {
  const prompts = await getPrompts();
  prompts.push(prompt);
  await savePrompts(prompts);
}

export async function deletePrompt(id: string): Promise<void> {
  const prompts = await getPrompts();
  await savePrompts(prompts.filter((p) => p.id !== id));
}

// ── Full state (for export/import) ──

export async function getFullState(): Promise<AppState> {
  const [folders, conversations, prompts] = await Promise.all([
    getFolders(),
    getConversations(),
    getPrompts(),
  ]);
  return { folders, conversations, prompts };
}

export async function importState(state: AppState): Promise<void> {
  await Promise.all([
    saveFolders(state.folders),
    saveConversations(state.conversations),
    savePrompts(state.prompts),
  ]);
}

// ── Utils ──

export function generateId(): string {
  return `${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}
