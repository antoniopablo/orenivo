import { useStore } from "@/lib/store";
import { PlatformBadge } from "./PlatformBadge";
import type { Conversation } from "@/lib/types";

export function ConversationItem({ conversation }: { conversation: Conversation }) {
  const { togglePinConversation } = useStore();

  const timeAgo = getTimeAgo(conversation.lastAccessed);

  return (
    <div className="flex items-center gap-2 px-2 py-1.5 rounded-md cursor-pointer group hover:bg-white/5 transition-all">
      <PlatformBadge platform={conversation.platform} />
      <a
        href={conversation.url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-[13px] text-gray-200 truncate flex-1 hover:text-white transition-colors"
        title={conversation.title}
      >
        {conversation.title}
      </a>
      {conversation.pinned && (
        <span className="text-amber-400 text-[10px]">📌</span>
      )}
      <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={(e) => {
            e.stopPropagation();
            togglePinConversation(conversation.id, conversation.platform);
          }}
          className="w-5 h-5 rounded flex items-center justify-center text-[9px] hover:bg-white/10 text-gray-500 hover:text-gray-300"
          title={conversation.pinned ? "Desfijar" : "Fijar"}
        >
          📌
        </button>
      </div>
      <span className="text-[10px] text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
        {timeAgo}
      </span>
    </div>
  );
}

function getTimeAgo(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "Ahora";
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d`;
  const weeks = Math.floor(days / 7);
  return `${weeks}sem`;
}
