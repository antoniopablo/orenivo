import { useState, useMemo } from "react";
import { useStore } from "@/lib/store";
import { ConversationItem } from "./ConversationItem";
import { FOLDER_COLORS } from "@/lib/types";
import type { Folder, Conversation } from "@/lib/types";

export function FolderList() {
  const {
    folders,
    conversations,
    searchQuery,
    platformFilter,
    activeTab,
    createFolder,
  } = useStore();

  const [newFolderName, setNewFolderName] = useState("");
  const [showNewFolder, setShowNewFolder] = useState(false);

  // Filter conversations based on search and platform
  const filtered = useMemo(() => {
    let result = conversations;
    if (platformFilter !== "all") {
      result = result.filter((c) => c.platform === platformFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter((c) => c.title.toLowerCase().includes(q));
    }
    return result;
  }, [conversations, platformFilter, searchQuery]);

  // Tab-based views
  if (activeTab === "pinned") {
    const pinned = filtered.filter((c) => c.pinned);
    return (
      <div className="space-y-0.5">
        {pinned.length === 0 ? (
          <EmptyState message="No tienes conversaciones fijadas. Usa 📌 para fijar." />
        ) : (
          pinned.map((c) => <ConversationItem key={`${c.platform}:${c.id}`} conversation={c} />)
        )}
      </div>
    );
  }

  if (activeTab === "recent") {
    const recent = [...filtered].sort((a, b) => b.lastAccessed - a.lastAccessed).slice(0, 30);
    return (
      <div className="space-y-0.5">
        {recent.length === 0 ? (
          <EmptyState message="No hay conversaciones recientes. Abre ChatGPT o Claude para sincronizar." />
        ) : (
          recent.map((c) => <ConversationItem key={`${c.platform}:${c.id}`} conversation={c} />)
        )}
      </div>
    );
  }

  // Folders view
  const rootFolders = folders
    .filter((f) => f.parentId === null)
    .sort((a, b) => a.order - b.order);

  const unfiled = filtered.filter((c) => c.folderId === null);

  return (
    <div className="space-y-0.5">
      {/* New Folder */}
      {showNewFolder ? (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (newFolderName.trim()) {
              createFolder(newFolderName.trim());
              setNewFolderName("");
              setShowNewFolder(false);
            }
          }}
          className="flex items-center gap-1.5 px-2 py-1.5"
        >
          <input
            autoFocus
            type="text"
            value={newFolderName}
            onChange={(e) => setNewFolderName(e.target.value)}
            onBlur={() => {
              if (!newFolderName.trim()) setShowNewFolder(false);
            }}
            placeholder="Nombre de la carpeta..."
            className="flex-1 bg-white/5 border border-brand-500/30 rounded px-2 py-1 text-xs text-white placeholder-gray-600 outline-none"
          />
          <button type="submit" className="text-brand-400 text-xs font-medium px-2 py-1 hover:bg-brand-500/10 rounded">
            ✓
          </button>
          <button
            type="button"
            onClick={() => setShowNewFolder(false)}
            className="text-gray-500 text-xs px-2 py-1 hover:bg-white/5 rounded"
          >
            ✕
          </button>
        </form>
      ) : (
        <button
          onClick={() => setShowNewFolder(true)}
          className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-[11px] text-brand-400 hover:bg-brand-500/10 transition-colors"
        >
          <span className="w-5 h-5 rounded-md border border-dashed border-brand-500/40 flex items-center justify-center text-[10px]">
            +
          </span>
          Nueva carpeta
        </button>
      )}

      {/* Folder tree */}
      {rootFolders.map((folder) => (
        <FolderItem key={folder.id} folder={folder} conversations={filtered} allFolders={folders} />
      ))}

      {/* Unfiled conversations */}
      {unfiled.length > 0 && (
        <div className="mt-3 pt-2 border-t border-white/5">
          <div className="px-2 py-1 text-[10px] text-gray-600 uppercase tracking-wider font-medium">
            Sin clasificar ({unfiled.length})
          </div>
          {unfiled.slice(0, 10).map((c) => (
            <ConversationItem key={`${c.platform}:${c.id}`} conversation={c} />
          ))}
          {unfiled.length > 10 && (
            <div className="px-2 py-1 text-[10px] text-gray-600">
              + {unfiled.length - 10} conversaciones más...
            </div>
          )}
        </div>
      )}

      {rootFolders.length === 0 && unfiled.length === 0 && (
        <EmptyState message="Abre ChatGPT o Claude en otra pestaña para ver tus conversaciones aquí." />
      )}
    </div>
  );
}

// ── Folder Item ──

function FolderItem({
  folder,
  conversations,
  allFolders,
  level = 0,
}: {
  folder: Folder;
  conversations: Conversation[];
  allFolders: Folder[];
  level?: number;
}) {
  const [expanded, setExpanded] = useState(level === 0);
  const { removeFolder, renameFolder } = useStore();
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState(folder.name);

  const childFolders = allFolders
    .filter((f) => f.parentId === folder.id)
    .sort((a, b) => a.order - b.order);

  const folderConvs = conversations.filter((c) => c.folderId === folder.id);
  const totalCount =
    folderConvs.length +
    childFolders.reduce(
      (acc, cf) => acc + conversations.filter((c) => c.folderId === cf.id).length,
      0
    );

  return (
    <div style={{ paddingLeft: level * 12 }}>
      <div
        className="flex items-center gap-1.5 px-2 py-1.5 rounded-md cursor-pointer hover:bg-white/5 group"
        onClick={() => setExpanded(!expanded)}
      >
        <span
          className="text-gray-400 text-[10px] w-3 transition-transform duration-200"
          style={{ transform: expanded ? "rotate(90deg)" : "rotate(0deg)" }}
        >
          ▶
        </span>
        <span className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: folder.color }} />

        {editing ? (
          <input
            autoFocus
            value={editName}
            onChange={(e) => setEditName(e.target.value)}
            onBlur={() => {
              if (editName.trim()) renameFolder(folder.id, editName.trim());
              setEditing(false);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                if (editName.trim()) renameFolder(folder.id, editName.trim());
                setEditing(false);
              }
              if (e.key === "Escape") setEditing(false);
            }}
            onClick={(e) => e.stopPropagation()}
            className="flex-1 bg-white/5 border border-brand-500/30 rounded px-1 py-0 text-[13px] text-white outline-none"
          />
        ) : (
          <span
            className="text-[13px] text-gray-100 font-medium truncate flex-1"
            onDoubleClick={(e) => {
              e.stopPropagation();
              setEditing(true);
            }}
          >
            {folder.name}
          </span>
        )}

        <span className="text-[10px] text-gray-500 px-1.5 py-0.5 rounded-full bg-white/5">
          {totalCount}
        </span>

        <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setEditing(true);
            }}
            className="w-4 h-4 rounded flex items-center justify-center text-[8px] hover:bg-white/10 text-gray-500"
            title="Renombrar"
          >
            ✎
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              if (confirm(`¿Eliminar carpeta "${folder.name}"?`)) {
                removeFolder(folder.id);
              }
            }}
            className="w-4 h-4 rounded flex items-center justify-center text-[8px] hover:bg-red-500/10 text-gray-500 hover:text-red-400"
            title="Eliminar"
          >
            🗑
          </button>
        </div>
      </div>

      {expanded && (
        <div className="folder-content ml-1">
          {childFolders.map((cf) => (
            <FolderItem
              key={cf.id}
              folder={cf}
              conversations={conversations}
              allFolders={allFolders}
              level={level + 1}
            />
          ))}
          {folderConvs.map((c) => (
            <ConversationItem key={`${c.platform}:${c.id}`} conversation={c} />
          ))}
          {folderConvs.length === 0 && childFolders.length === 0 && (
            <div className="px-2 py-2 text-[11px] text-gray-600 italic">
              Arrastra conversaciones aquí...
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Empty State ──

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
      <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center text-2xl mb-3">
        📂
      </div>
      <p className="text-xs text-gray-500 leading-relaxed max-w-[200px]">{message}</p>
    </div>
  );
}
