import { useStore } from "@/lib/store";

export function StatusBar() {
  const { conversations, folders } = useStore();

  const platforms = new Set(conversations.map((c) => c.platform));

  return (
    <div className="px-3 py-2 border-t border-white/5 flex items-center justify-between">
      <div className="flex items-center gap-1.5">
        <span className="w-2 h-2 rounded-full bg-brand-500 animate-pulse" />
        <span className="text-[10px] text-gray-500">Local</span>
      </div>
      <div className="flex gap-2 text-[10px] text-gray-500">
        <span>{platforms.size} plataforma{platforms.size !== 1 ? "s" : ""}</span>
        <span>·</span>
        <span>{conversations.length} chats</span>
        <span>·</span>
        <span>{folders.length} carpetas</span>
      </div>
    </div>
  );
}
