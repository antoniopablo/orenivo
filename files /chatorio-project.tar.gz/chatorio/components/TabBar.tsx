import { useStore } from "@/lib/store";

const tabs = [
  { id: "folders" as const, icon: "📁", label: "Carpetas" },
  { id: "recent" as const, icon: "🕐", label: "Recientes" },
  { id: "pinned" as const, icon: "📌", label: "Fijados" },
];

export function TabBar() {
  const { activeTab, setActiveTab } = useStore();

  return (
    <div className="flex border-b border-white/5">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => setActiveTab(tab.id)}
          className={`flex-1 py-2 text-[11px] font-medium transition-all border-b-2 ${
            activeTab === tab.id
              ? "text-brand-400 border-brand-500"
              : "text-gray-500 border-transparent hover:text-gray-300"
          }`}
        >
          {tab.icon} {tab.label}
        </button>
      ))}
    </div>
  );
}
