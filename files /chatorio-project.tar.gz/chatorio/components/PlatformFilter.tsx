import { useStore } from "@/lib/store";
import { PLATFORMS, type Platform } from "@/lib/types";

export function PlatformFilter() {
  const { platformFilter, setPlatformFilter } = useStore();

  return (
    <div className="flex gap-1">
      <FilterChip
        label="Todas"
        active={platformFilter === "all"}
        onClick={() => setPlatformFilter("all")}
      />
      {Object.values(PLATFORMS).map((p) => (
        <FilterChip
          key={p.id}
          label={p.icon + " " + p.name.slice(0, 3)}
          active={platformFilter === p.id}
          color={p.color}
          onClick={() => setPlatformFilter(p.id)}
        />
      ))}
    </div>
  );
}

function FilterChip({
  label,
  active,
  color,
  onClick,
}: {
  label: string;
  active: boolean;
  color?: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`px-2 py-1 rounded-md text-[10px] font-medium transition-all ${
        active
          ? "bg-white/10 text-white"
          : "text-gray-500 hover:text-gray-300 hover:bg-white/5"
      }`}
      style={active && color ? { color } : undefined}
    >
      {label}
    </button>
  );
}
